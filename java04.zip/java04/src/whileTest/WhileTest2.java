package whileTest;

public class WhileTest2 {

	public static void main(String[] args) {
		int num = 1;
		int sum = 0;
		while (num < 101) {
			sum += num++; // sum = sum + num;
							// num ++;
		}
		System.out.println(sum);
	}
}
