
package whileTest;

import java.util.Random;
import java.util.Scanner;

public class WhileTest7 {

	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);
		System.out.print("������>>");
		int su1 = a.nextInt();
		System.out.print("��ǰ�� �Ѿ�>>");
		int su2 = a.nextInt();
		System.out.println("�ΰ���>>" + (su2 * 0.1));
		System.out.print("�ܵ� >>" + (su1 - su2));

	}
}
