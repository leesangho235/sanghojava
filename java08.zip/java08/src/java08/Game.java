package java08;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;

public class Game {
	private static JTextField intro;
	private static JTextField result;

	// 글로벌 변수 전체에서 모든 변수를 다 씀 클래스밑에 씀.
	static int s = 0;
	static int r = 1;
	static int p = 2;
	static int all = 0;
	static int win = 0;
	static int lose = 0;
	static int same = 0;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\user\\Desktop\\1.jpg"));
		f.setTitle("가위바위보 게임!");
		f.setSize(800, 500);

		intro = new JTextField();
		intro.setBackground(new Color(60, 179, 113));
		intro.setFont(new Font("굴림", Font.BOLD, 14));
		intro.setText("가위바위보 게임을 시작합니다.! 원하는 버튼을 눌러주세요!");
		f.getContentPane().add(intro, BorderLayout.NORTH);
		intro.setColumns(10);

		result = new JTextField();
		result.setForeground(new Color(139, 0, 0));
		result.setBackground(new Color(255, 255, 0));
		result.setFont(new Font("굴림", Font.BOLD, 18));
		result.setText("아직 게임 시작 전 입니다.");
		f.getContentPane().add(result, BorderLayout.SOUTH);
		result.setColumns(10);

		JPanel panel = new JPanel();
		f.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(1, 0, 0, 0));

		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				all++;

				f.setTitle("나의 가위 바위 보 게임(총 게임횟수: " + all + "회))");
				System.out.println("가위를 선택하셨군요");
				int me = 0; // 가위 냄
				Random rand = new Random();
				int computer = rand.nextInt(3);

				if (computer == me) {
					result.setText("무승부");
					same++;
				} else if (computer == r) {
					result.setText("컴퓨터 승리!");
					lose++;
				} else {
					result.setText("내가 승리!");
					win++;
				}
				intro.setText("내가 승리 횟수 : " + win + ", 컴퓨터가 승리 횟수 : " + lose + ", 무승부 횟수 : " + same);
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\2.jpg"));
		btnNewButton.setBackground(new Color(218, 165, 32));
		panel.add(btnNewButton);

		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				all++;
				f.setTitle("나의 가위 바위 보 게임(총 게임횟수: " + all + "회))");
				System.out.println("바위를 선택하셨군요");
				int me = 1; // 바위 냄
				Random rand = new Random();
				int computer = rand.nextInt(3);

				if (computer == me) {
					result.setText("무승부");
					same++;
				} else if (computer == p) {
					result.setText("컴퓨터 승리!");
					lose++;
				} else {
					result.setText("내가 승리!");
					win++;
				}
				intro.setText("내가 승리 횟수 : " + win + ", 컴퓨터가 승리 횟수 : " + lose + ", 무승부 횟수 : " + same);
			}
		});
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\1.jpg"));
		btnNewButton_2.setBackground(new Color(173, 255, 47));
		panel.add(btnNewButton_2);

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("보자기를 선택하셨군요");
				all++;
				f.setTitle("나의 가위 바위 보 게임(총 게임횟수: " + all + "회))");
				int me = 2; // 보 냄
				Random rand = new Random();
				int computer = rand.nextInt(3);

				if (computer == me) {
					result.setText("무승부");
					same++;
				} else if (computer == s) {
					result.setText("컴퓨터 승리!");
					lose++;
				} else {
					result.setText("내가 승리!");
					win++;
				}
				intro.setText("내가 승리 횟수 : " + win + ", 컴퓨터가 승리 횟수 : " + lose + ", 무승부 횟수 : " + same);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\3.jpg"));
		btnNewButton_1.setBackground(new Color(250, 128, 114));
		panel.add(btnNewButton_1);

		f.setVisible(true);
	}

}
