package java08;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ImageIcon;

public class SecondWindow {

	public static void main(String[] args) {
		JFrame f = new JFrame(); // 1번
		f.getContentPane().setBackground(Color.YELLOW);
		f.setTitle("나의 메뉴판");
		f.setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\leesangho\\java07\\ham.jpg"));
		f.setBackground(Color.ORANGE);
		f.setSize(1500, 300); // 2번
		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JButton btnNewButton = new JButton("나를 눌러요");
		btnNewButton.setFont(new Font("궁서체", Font.PLAIN, 13));
		btnNewButton.setToolTipText("내가보이나");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("버튼을 눌렀군요");
			}
		});

		JButton button = new JButton("");
		button.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\ham2.jpg"));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("햄버거 버튼을 누르셨군요");
			}
		});
		f.getContentPane().add(button);
		f.getContentPane().add(btnNewButton);

		f.setVisible(true);// 3번

	}

}
