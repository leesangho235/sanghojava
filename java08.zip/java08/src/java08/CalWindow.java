package java08;

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class CalWindow {
	private static JTextField n1;
	private static JTextField n2;
	private static JTextField result;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GRAY);
		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JLabel label_1 = new JLabel("숫자1>");
		label_1.setForeground(new Color(25, 25, 112));
		label_1.setFont(new Font("굴림", Font.BOLD, 16));
		f.getContentPane().add(label_1);

		n1 = new JTextField();
		n1.setFont(new Font("굴림", Font.BOLD | Font.ITALIC, 18));
		f.getContentPane().add(n1);
		n1.setColumns(10);

		JLabel label = new JLabel("숫자2>");
		label.setForeground(new Color(25, 25, 112));
		label.setFont(new Font("굴림", Font.BOLD, 16));
		f.getContentPane().add(label);

		n2 = new JTextField();
		n2.setFont(new Font("굴림", Font.BOLD | Font.ITALIC, 18));
		n2.setColumns(10);
		f.getContentPane().add(n2);

		JButton add = new JButton("더하기 연산");
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("더하기 버튼을 누르셨군요.!");
				String num = n1.getText();
				String num2 = n2.getText();
				System.out.println("입력한 숫자값 : " + num);
				System.out.println("입력한 숫자값 : " + num2);

				int n11 = Integer.parseInt(num);
				int n12 = Integer.parseInt(num2);
				int sum = n11 + n12;
				System.out.println("두 수를 더한 값은" + sum);
				result.setText(sum+"");

			}
		});
		add.setBackground(new Color(128, 128, 0));
		add.setForeground(new Color(0, 0, 0));
		add.setFont(new Font("굴림", Font.ITALIC, 20));
		f.getContentPane().add(add);
		
		JButton sub = new JButton("빼기 연산");
		sub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			System.out.println("빼기 버튼을 누르셨군요.!");
			String num = n1.getText();
			String num2 = n2.getText();
			int n13 = Integer.parseInt(num);
			int n14 = Integer.parseInt(num2);
			int sub = n13 - n14;
			result.setText(sub + "");
					
				
			}
		});
		sub.setBackground(new Color(186, 85, 211));
		sub.setFont(new Font("굴림", Font.ITALIC, 21));
		f.getContentPane().add(sub);

		result = new JTextField();
		result.setBackground(new Color(240, 230, 140));
		result.setForeground(new Color(139, 69, 19));
		result.setFont(new Font("굴림", Font.BOLD, 25));
		f.getContentPane().add(result);
		result.setColumns(10);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\kal.jpg"));
		f.getContentPane().add(btnNewButton);
		f.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\user\\Desktop\\kal.jpg"));
		f.setTitle("나의 계산기");

		f.setSize(311, 447);
		f.setVisible(true);

	}
}
