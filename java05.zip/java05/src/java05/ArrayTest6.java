package java05;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class ArrayTest6 {

	public static void main(String[] args) {

		int[] a = { 88, 77, 55, 44, 11, 66, 99 };
		for (int i = 0; i < a.length; i++) {
			System.out.println(i + ":" + a[i]);

		}
	}

}
