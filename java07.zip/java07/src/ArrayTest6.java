import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class ArrayTest6 {

	public static void main(String[] args) {
		int[] num = { 99, 10, 21, 35, 24, 50 };
		Arrays.sort(num);
		for (int i = 0; i < num.length; i++) {
			if (num[i]==24) {
				System.out.println(i+1+"��");
			}
		}		
	}
}