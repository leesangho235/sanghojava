package array;

public class ArrayTest2 {

	public static void main(String[] args) {
		int[] s = new int[5];
		s[0] = 1;
		s[2] = 3;
		s[4] = 5;
		System.out.println(s.length); // ���� length�Լ� ���
		for (int i = 0; i < s.length; i++) {
			System.out.println(i+"�ε��� ��:"+s[i]);
		}

	}

}
